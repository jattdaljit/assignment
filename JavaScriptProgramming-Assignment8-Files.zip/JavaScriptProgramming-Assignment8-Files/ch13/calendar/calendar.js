"use strict";
$(document).ready(function(){
    var getMonthText = function(currentMonth) {
        if (currentMonth === 0) { return "January"; }
        else if (currentMonth === 1) { return "February"; }
        else if (currentMonth === 2) { return "March"; }
        else if (currentMonth === 3) { return "April"; }
        else if (currentMonth === 4) { return "May"; }
        else if (currentMonth === 5) { return "June"; }
        else if (currentMonth === 6) { return "July"; }
        else if (currentMonth === 7) { return "August"; }
        else if (currentMonth === 8) { return "September"; }
        else if (currentMonth === 9) { return "October"; }
        else if (currentMonth === 10) { return "November"; }
        else if (currentMonth === 11) { return "December"; }
    };

    var getLastDayofMonth = function(currentMonth) {
		var date = new Date();
		return  new Date(date.getFullYear(), currentMonth +1, 0).getDate();
    };
    
	init();
	function init() {
		var date = new Date();
		var currentMonth = date.getMonth();
		var month = getMonthText(currentMonth);
		var year = date.getFullYear();
		$("#month_year").append(month+" "+year);
		
		var dt = new Date(year, currentMonth, 1);
		var firstDay = dt.getDay(); 
		var lastDay = getLastDayofMonth(currentMonth);
		var data;
		for(var i=0; i < firstDay + lastDay ; i++){
			if(i == 0 || i%7 == 0){
				data += "<tr>";
			}
			if( i < firstDay){
				data += "<td></td>";
			}else{
				var print = i - (firstDay - 1);
				if(print <= lastDay){
				data += "<td>" + print + "</td>";	
				} else {
					data += "<td></td>";
				}
			}
			if(i%7 == 6 && i != 0) {
				data += "</tr>";
			}
		}
		
		$("#calendar").append(data);
		
		
			
	}

});