"use strict";
$(document).ready(function(){
    $("#calculate").click( function() {
	document.getElementById("quarters").value = "";
	document.getElementById("dimes").value = "";
	document.getElementById("nickels").value = "";
	document.getElementById("pennies").value = "";
	var cents = document.getElementById("cents").value ; 
	if(cents > 0 && cents < 99){
			while(cents > 0) {
	if(cents >= 25) {
	var quarters = Math.floor(cents/25);
	cents = cents%25;
	document.getElementById("quarters").value = quarters;
	} else {
		if(cents >= 10) {
			var dimes = Math.floor(cents/10);
			cents = cents%10;
			document.getElementById("dimes").value = dimes;
		}else {
			if(cents >= 5){
				var nickles = Math.floor(cents/5);
				cents = cents%5;
				console.log(cents);
				document.getElementById("nickels").value = nickles;
			} else{
				document.getElementById("pennies").value = cents;
				cents = cents%1;
			}
		}
		
	}
	}
	} else {
		alert("Please enter a valid number between 0 and 99");
	}
	
	
	

	
    }); // end click() method
    
    // set focus on cents text box on initial load
    $("#cents").focus();
            
}); // end ready() method